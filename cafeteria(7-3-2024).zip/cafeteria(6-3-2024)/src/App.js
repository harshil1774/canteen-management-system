
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import PaymentPage from "./pages/PaymentPage";
import ReviewsPage from "./pages/ReviewsPage";
import OrderTracking from "./pages/OrderTracking";
import ContactPage from "./pages/ContactPage";
import Navbar from "./pages/Navbar";
import Footer from "./pages/Footer.js";

import CartPage from "./pages/CartPage";
import CheckoutPage from "./pages/CheckoutPage";
import AdminDashboard from "./pages/AdminDashboard";
import LoginPage from "./pages/LoginPage";
import SignupPage from "./pages/SignupPage";

import HomePage from "./pages/HomePage";
import MenuPage from "./pages/MenuPage";






function App() {
  return (
<Router>
<Navbar />

        <Routes>
          <Route path="/" element={<HomePage />} />
         // <Route path="/OrderTracking" element={<OrderTracking />} />
          <Route path="/ReviewsPage" element={<ReviewsPage />} />
          <Route path="/HomePage" element={<HomePage />} />
          <Route path="/PaymentPage" element={<PaymentPage />} />
          <Route path="/ContactPage " element={<ContactPage />} />
          <Route path="/CartPage" element={<CartPage />} />
          <Route path="/CheckoutPage" element={<CheckoutPage />} />
          <Route path="/MenuPage" element={<MenuPage />} />
          <Route path="/AdminDashboard" element={<AdminDashboard />} />
          <Route path="/LoginPage" element={<LoginPage />} />
          <Route path="/SignupPage" element={<SignupPage />} />






          </Routes>
          <Footer />
            </Router>


  );
}

export default App;
