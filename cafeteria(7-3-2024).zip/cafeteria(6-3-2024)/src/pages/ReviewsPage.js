import React, { useState } from "react";
import "./ReviewsPage.css";

const ReviewsPage = () => {
  const [reviews, setReviews] = useState([
    { id: 1, name: "John Doe", rating: 5, comment: "Amazing food and great service!" },
    { id: 2, name: "Jane Smith", rating: 4, comment: "Loved the ambiance, will visit again." }
  ]);
  const [newReview, setNewReview] = useState({ name: "", rating: 5, comment: "" });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewReview({ ...newReview, [name]: value });
  };

  const submitReview = (e) => {
    e.preventDefault();
    if (newReview.name && newReview.comment) {
      setReviews([...reviews, { id: reviews.length + 1, ...newReview }]);
      setNewReview({ name: "", rating: 5, comment: "" });
    }
  };

  return (
    <div className="reviews-container">
      <h2>Customer Reviews</h2>
      <ul className="reviews-list">
        {reviews.map(review => (
          <li key={review.id} className="review-item">
            <h3>{review.name}</h3>
            <p>Rating: {"⭐".repeat(review.rating)}</p>
            <p>{review.comment}</p>
          </li>
        ))}
      </ul>

      <form className="review-form" onSubmit={submitReview}>
        <h3>Leave a Review</h3>
        <input
          type="text"
          name="name"
          value={newReview.name}
          onChange={handleInputChange}
          placeholder="Your Name"
          required
        />
        <select name="rating" value={newReview.rating} onChange={handleInputChange}>
          {[5, 4, 3, 2, 1].map(num => (
            <option key={num} value={num}>{num} Stars</option>
          ))}
        </select>
        <textarea
          name="comment"
          value={newReview.comment}
          onChange={handleInputChange}
          placeholder="Write your review..."
          required
        ></textarea>
        <button type="submit">Submit Review</button>
      </form>
    </div>
  );
};

export default ReviewsPage;