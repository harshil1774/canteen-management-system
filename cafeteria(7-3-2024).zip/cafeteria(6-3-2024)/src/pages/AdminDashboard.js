import React, { useState } from "react";
import "./AdminDashboard.css";

const AdminDashboard = () => {
  const [menuItems, setMenuItems] = useState([
    { id: 1, name: "Burger", price: 99 },
    { id: 2, name: "Pasta", price: 199 },
    { id: 3, name: "Coffee", price: 79 }
  ]);

  const handleAddItem = () => {
    const newItem = { id: Date.now(), name: "New Item", price: 0 };
    setMenuItems([...menuItems, newItem]);
  };

  const handleDeleteItem = (id) => {
    setMenuItems(menuItems.filter(item => item.id !== id));
  };

  return (
    <div className="admin-dashboard">
      <h2>Admin Dashboard</h2>
      <button onClick={handleAddItem} className="add-button">Add New Item</button>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Price ($)</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {menuItems.map((item) => (
            <tr key={item.id}>
              <td>{item.name}</td>
              <td>{item.price.toFixed(2)}</td>
              <td>
                <button className="delete-button" onClick={() => handleDeleteItem(item.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AdminDashboard;
