import React, { useState } from "react";
import "./OrderTracking.css";

const orders = [
  { id: 1, status: "Pending" },
  { id: 2, status: "In Progress" },
  { id: 3, status: "Ready for Pickup" },
];

const OrderTracking = () => {
  const [orderStatus, setOrderStatus] = useState(orders);

  const updateStatus = (id) => {
    setOrderStatus(orderStatus.map(order => 
      order.id === id ? { ...order, status: getNextStatus(order.status) } : order
    ));
  };

  const getNextStatus = (currentStatus) => {
    const statuses = ["Pending", "In Progress", "Ready for Pickup", "Completed"];
    const currentIndex = statuses.indexOf(currentStatus);
    return currentIndex < statuses.length - 1 ? statuses[currentIndex + 1] : currentStatus;
  };

  return (
    <div className="order-tracking-container">
      <h2>Order Tracking</h2>
      <table>
        <thead>
          <tr>
            <th>Order ID</th>
            <th>Status</th>
            <th>Update</th>
          </tr>
        </thead>
        <tbody>
          {orderStatus.map(order => (
            <tr key={order.id}>
              <td>{order.id}</td>
              <td>{order.status}</td>
              <td>
                {order.status !== "Completed" && (
                  <button onClick={() => updateStatus(order.id)}>Next Status</button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default OrderTracking;