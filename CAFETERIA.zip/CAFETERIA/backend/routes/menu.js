const express = require('express');
const router = express.Router();
const MenuItem = require('../models/MenuItem');

// सभी मेनू आइटम्स प्राप्त करें
router.get('/', async (req, res) => {
  try {
    const menuItems = await MenuItem.find();
    res.json(menuItems);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// श्रेणी के अनुसार मेनू आइटम्स प्राप्त करें
router.get('/category/:category', async (req, res) => {
  try {
    const menuItems = await MenuItem.find({ category: req.params.category });
    res.json(menuItems);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router; 