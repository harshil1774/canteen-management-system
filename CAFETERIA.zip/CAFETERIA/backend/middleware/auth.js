const jwt = require('jsonwebtoken');

module.exports = function(req, res, next) {
  // टोकन को हेडर से प्राप्त करें
  const token = req.header('x-auth-token');

  // टोकन की जांच करें
  if (!token) {
    return res.status(401).json({ message: 'No token, authorization denied' });
  }

  try {
    // टोकन को वेरिफाई करें
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded.user;
    next();
  } catch (err) {
    res.status(401).json({ message: 'Token is not valid' });
  }
}; 