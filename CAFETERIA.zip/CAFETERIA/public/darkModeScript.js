// This script applies inline styles for dark mode
(function() {
  // Check if dark mode is enabled
  const isDarkMode = localStorage.getItem('darkMode') === 'true';
  
  if (isDarkMode) {
    // Apply dark mode class to body
    document.body.classList.add('dark-mode');
    
    // Apply inline styles to ensure text visibility
    const style = document.createElement('style');
    style.textContent = `
      body.dark-mode {
        background-color: #121212 !important;
        color: #ffffff !important;
      }
      
      body.dark-mode h1,
      body.dark-mode h2,
      body.dark-mode h3,
      body.dark-mode h4,
      body.dark-mode h5,
      body.dark-mode h6,
      body.dark-mode p,
      body.dark-mode span,
      body.dark-mode div,
      body.dark-mode a,
      body.dark-mode button,
      body.dark-mode input,
      body.dark-mode label,
      body.dark-mode li,
      body.dark-mode td,
      body.dark-mode th {
        color: #ffffff !important;
        visibility: visible !important;
        opacity: 1 !important;
      }
      
      body.dark-mode .MuiTypography-root,
      body.dark-mode .MuiButton-root,
      body.dark-mode .MuiInputBase-root,
      body.dark-mode .MuiTableCell-root,
      body.dark-mode .MuiPaper-root {
        color: #ffffff !important;
      }
    `;
    
    document.head.appendChild(style);
  }
})(); 