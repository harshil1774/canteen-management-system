import React, { useState, useEffect } from "react";
import "./ReviewsPage.css";

const ReviewsPage = () => {
  // Get initial reviews from localStorage or use default empty array
  const [reviews, setReviews] = useState(() => {
    const savedReviews = localStorage.getItem('reviews');
    return savedReviews ? JSON.parse(savedReviews) : [
      { id: 1, name: "John Doe", rating: 5, comment: "Amazing food and great service!" },
      { id: 2, name: "Jane Smith", rating: 4, comment: "Loved the ambiance, will visit again." }
    ];
  });
  
  const [newReview, setNewReview] = useState({ name: "", rating: 5, comment: "" });

  // Save reviews to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('reviews', JSON.stringify(reviews));
  }, [reviews]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewReview({ ...newReview, [name]: value });
  };

  const submitReview = (e) => {
    e.preventDefault();
    if (newReview.name && newReview.comment) {
      const reviewToAdd = {
        id: Date.now(), // Use timestamp as unique ID
        ...newReview,
        date: new Date().toLocaleDateString() // Add submission date
      };
      setReviews([...reviews, reviewToAdd]);
      setNewReview({ name: "", rating: 5, comment: "" });
    }
  };

  return (
    <div className="reviews-container">
      <h2>Customer Reviews</h2>
      <ul className="reviews-list">
        {reviews.map(review => (
          <li key={review.id} className="review-item">
            <h3>{review.name}</h3>
            <p>Rating: {"⭐".repeat(review.rating)}</p>
            <p>{review.comment}</p>
            <small>Posted on: {review.date}</small>
          </li>
        ))}
      </ul>

      <form className="review-form" onSubmit={submitReview}>
        <h3>Leave a Review</h3>
        <input
          type="text"
          name="name"
          value={newReview.name}
          onChange={handleInputChange}
          placeholder="Your Name"
          required
        />
        <select name="rating" value={newReview.rating} onChange={handleInputChange}>
          {[5, 4, 3, 2, 1].map(num => (
            <option key={num} value={num}>{num} Stars</option>
          ))}
        </select>
        <textarea
          name="comment"
          value={newReview.comment}
          onChange={handleInputChange}
          placeholder="Write your review..."
          required
        ></textarea>
        <button type="submit">Submit Review</button>
      </form>
    </div>
  );
};

export default ReviewsPage;