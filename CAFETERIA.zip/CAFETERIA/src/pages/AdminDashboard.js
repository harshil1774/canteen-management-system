import React, { useState } from "react";
import { 
  Box, 
  Tabs, 
  Tab, 
  Typography, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow, 
  Paper, 
  Button, 
  TextField, 
  Dialog, 
  DialogActions, 
  DialogContent, 
  DialogTitle,
  IconButton,
  Card,
  CardContent,
  Grid,
  Chip
} from '@mui/material';
import {
  Add as AddIcon,
  Delete as DeleteIcon,
  Edit as EditIcon,
  Refresh as RefreshIcon,
  Dashboard as DashboardIcon,
  Restaurant as MenuIcon,
  ShoppingCart as OrdersIcon,
  People as UsersIcon
} from '@mui/icons-material';
import "./AdminDashboard.css";

// Tab Panel Component
function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
}

const AdminDashboard = () => {
  const [tabValue, setTabValue] = useState(0);
  const [menuItems, setMenuItems] = useState([
    { id: 1, name: "Burger", category: "Fast Food", price: 99, available: true },
    { id: 2, name: "Pasta", category: "Italian", price: 199, available: true },
    { id: 3, name: "Coffee", category: "Beverages", price: 79, available: true },
    { id: 4, name: "Pizza", category: "Fast Food", price: 249, available: false }
  ]);
  
  const [orders, setOrders] = useState([
    { id: 1001, customer: "Rahul Sharma", items: ["Burger", "Coffee"], total: 178, status: "Pending", date: "2023-07-01" },
    { id: 1002, customer: "Priya Verma", items: ["Pasta"], total: 199, status: "Delivered", date: "2023-07-02" },
    { id: 1003, customer: "Amit Singh", items: ["Pizza", "Coffee"], total: 328, status: "Processing", date: "2023-07-03" }
  ]);
  
  const [users, setUsers] = useState([
    { id: 101, name: "Rahul Sharma", email: "rahul@example.com", role: "Customer", orders: 5 },
    { id: 102, name: "Priya Verma", email: "priya@example.com", role: "Customer", orders: 3 },
    { id: 103, name: "Amit Singh", email: "amit@example.com", role: "Admin", orders: 0 }
  ]);

  // Dialog States
  const [openMenuDialog, setOpenMenuDialog] = useState(false);
  const [currentMenuItem, setCurrentMenuItem] = useState({ name: "", category: "", price: 0, available: true });
  const [isEditing, setIsEditing] = useState(false);

  // Tab Change Handler
  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  // Menu Item Dialog Handlers
  const handleOpenMenuDialog = (item = null) => {
    if (item) {
      setCurrentMenuItem(item);
      setIsEditing(true);
    } else {
      setCurrentMenuItem({ name: "", category: "", price: 0, available: true });
      setIsEditing(false);
    }
    setOpenMenuDialog(true);
  };

  const handleCloseMenuDialog = () => {
    setOpenMenuDialog(false);
  };

  const handleMenuItemChange = (e) => {
    const { name, value } = e.target;
    setCurrentMenuItem({
      ...currentMenuItem,
      [name]: name === "price" ? Number(value) : value
    });
  };

  const handleToggleAvailability = (id) => {
    setMenuItems(menuItems.map(item => 
      item.id === id ? { ...item, available: !item.available } : item
    ));
  };

  const handleSaveMenuItem = () => {
    if (isEditing) {
      setMenuItems(menuItems.map(item => 
        item.id === currentMenuItem.id ? currentMenuItem : item
      ));
    } else {
      const newItem = {
        ...currentMenuItem,
        id: Date.now()
      };
      setMenuItems([...menuItems, newItem]);
    }
    handleCloseMenuDialog();
  };

  const handleDeleteMenuItem = (id) => {
    setMenuItems(menuItems.filter(item => item.id !== id));
  };

  // Order Status Update Handler
  const handleUpdateOrderStatus = (id, newStatus) => {
    setOrders(orders.map(order => 
      order.id === id ? { ...order, status: newStatus } : order
    ));
  };

  // Dashboard Statistics
  const totalRevenue = orders.reduce((sum, order) => sum + order.total, 0);
  const pendingOrders = orders.filter(order => order.status === "Pending").length;
  const totalMenuItems = menuItems.length;
  const totalUsers = users.length;

  return (
    <div className="admin-dashboard">
      <Typography variant="h4" component="h1" gutterBottom>
        Admin Dashboard
      </Typography>

      {/* Dashboard Tabs */}
      <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Tabs value={tabValue} onChange={handleTabChange} aria-label="admin dashboard tabs">
          <Tab icon={<DashboardIcon />} label="Dashboard" />
          <Tab icon={<MenuIcon />} label="Menu Items" />
          <Tab icon={<OrdersIcon />} label="Orders" />
          <Tab icon={<UsersIcon />} label="Users" />
        </Tabs>
      </Box>

      {/* Dashboard Overview */}
      <TabPanel value={tabValue} index={0}>
        <Grid container spacing={3}>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent>
                <Typography color="textSecondary" gutterBottom>
                  Total Revenue
                </Typography>
                <Typography variant="h5" component="h2">
                  ₹{totalRevenue}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent>
                <Typography color="textSecondary" gutterBottom>
                  Pending Orders
                </Typography>
                <Typography variant="h5" component="h2">
                  {pendingOrders}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent>
                <Typography color="textSecondary" gutterBottom>
                  Menu Items
                </Typography>
                <Typography variant="h5" component="h2">
                  {totalMenuItems}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent>
                <Typography color="textSecondary" gutterBottom>
                  Users
                </Typography>
                <Typography variant="h5" component="h2">
                  {totalUsers}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>

        <Box sx={{ mt: 4 }}>
          <Typography variant="h6" gutterBottom>
            Recent Orders
          </Typography>
          <TableContainer component={Paper}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Order ID</TableCell>
                  <TableCell>Customer</TableCell>
                  <TableCell>Total</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Date</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {orders.slice(0, 5).map((order) => (
                  <TableRow key={order.id}>
                    <TableCell>{order.id}</TableCell>
                    <TableCell>{order.customer}</TableCell>
                    <TableCell>₹{order.total}</TableCell>
                    <TableCell>
                      <Chip 
                        label={order.status} 
                        color={
                          order.status === "Delivered" ? "success" : 
                          order.status === "Pending" ? "warning" : "info"
                        } 
                      />
                    </TableCell>
                    <TableCell>{order.date}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      </TabPanel>

      {/* Menu Items Tab */}
      <TabPanel value={tabValue} index={1}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
          <Typography variant="h6">Menu Items Management</Typography>
          <Button 
            variant="contained" 
            color="primary" 
            startIcon={<AddIcon />}
            onClick={() => handleOpenMenuDialog()}
          >
            Add New Item
          </Button>
        </Box>

        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Name</TableCell>
                <TableCell>Category</TableCell>
                <TableCell>Price (₹)</TableCell>
                <TableCell>Availability</TableCell>
                <TableCell>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {menuItems.map((item) => (
                <TableRow key={item.id}>
                  <TableCell>{item.name}</TableCell>
                  <TableCell>{item.category}</TableCell>
                  <TableCell>{item.price}</TableCell>
                  <TableCell>
                    <Chip 
                      label={item.available ? "Available" : "Unavailable"} 
                      color={item.available ? "success" : "error"}
                      onClick={() => handleToggleAvailability(item.id)}
                    />
                  </TableCell>
                  <TableCell>
                    <IconButton color="primary" onClick={() => handleOpenMenuDialog(item)}>
                      <EditIcon />
                    </IconButton>
                    <IconButton color="error" onClick={() => handleDeleteMenuItem(item.id)}>
                      <DeleteIcon />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>

        {/* Menu Item Dialog */}
        <Dialog open={openMenuDialog} onClose={handleCloseMenuDialog}>
          <DialogTitle>{isEditing ? "Edit Item" : "Add New Item"}</DialogTitle>
          <DialogContent>
            <TextField
              autoFocus
              margin="dense"
              name="name"
              label="Item Name"
              type="text"
              fullWidth
              value={currentMenuItem.name}
              onChange={handleMenuItemChange}
            />
            <TextField
              margin="dense"
              name="category"
              label="Category"
              type="text"
              fullWidth
              value={currentMenuItem.category}
              onChange={handleMenuItemChange}
            />
            <TextField
              margin="dense"
              name="price"
              label="Price (₹)"
              type="number"
              fullWidth
              value={currentMenuItem.price}
              onChange={handleMenuItemChange}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={handleCloseMenuDialog} color="primary">
              Cancel
            </Button>
            <Button onClick={handleSaveMenuItem} color="primary">
              Save
            </Button>
          </DialogActions>
        </Dialog>
      </TabPanel>

      {/* Orders Tab */}
      <TabPanel value={tabValue} index={2}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
          <Typography variant="h6">Orders Management</Typography>
          <Button 
            variant="outlined" 
            color="primary" 
            startIcon={<RefreshIcon />}
          >
            Refresh
          </Button>
        </Box>

        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Order ID</TableCell>
                <TableCell>Customer</TableCell>
                <TableCell>Items</TableCell>
                <TableCell>Total</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Date</TableCell>
                <TableCell>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {orders.map((order) => (
                <TableRow key={order.id}>
                  <TableCell>{order.id}</TableCell>
                  <TableCell>{order.customer}</TableCell>
                  <TableCell>{order.items.join(", ")}</TableCell>
                  <TableCell>₹{order.total}</TableCell>
                  <TableCell>
                    <Chip 
                      label={order.status} 
                      color={
                        order.status === "Delivered" ? "success" : 
                        order.status === "Pending" ? "warning" : "info"
                      } 
                    />
                  </TableCell>
                  <TableCell>{order.date}</TableCell>
                  <TableCell>
                    <select 
                      value={order.status}
                      onChange={(e) => handleUpdateOrderStatus(order.id, e.target.value)}
                      className="status-select"
                    >
                      <option value="Pending">Pending</option>
                      <option value="Processing">Processing</option>
                      <option value="Shipped">Shipped</option>
                      <option value="Delivered">Delivered</option>
                      <option value="Cancelled">Cancelled</option>
                    </select>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </TabPanel>

      {/* Users Tab */}
      <TabPanel value={tabValue} index={3}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
          <Typography variant="h6">Users Management</Typography>
        </Box>

        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>ID</TableCell>
                <TableCell>Name</TableCell>
                <TableCell>Email</TableCell>
                <TableCell>Role</TableCell>
                <TableCell>Orders</TableCell>
                <TableCell>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {users.map((user) => (
                <TableRow key={user.id}>
                  <TableCell>{user.id}</TableCell>
                  <TableCell>{user.name}</TableCell>
                  <TableCell>{user.email}</TableCell>
                  <TableCell>{user.role}</TableCell>
                  <TableCell>{user.orders}</TableCell>
                  <TableCell>
                    <IconButton color="primary">
                      <EditIcon />
                    </IconButton>
                    <IconButton color="error">
                      <DeleteIcon />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </TabPanel>
    </div>
  );
};

export default AdminDashboard; 