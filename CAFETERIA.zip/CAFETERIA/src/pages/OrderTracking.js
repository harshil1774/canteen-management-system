import React, { useState } from "react";
import "./OrderTracking.css";

const orders = [
  { 
    id: 1, 
    customerName: "Rahul Sharma",
    items: ["Burger", "Cold Drink"],
    status: "Pending" 
  },
  { 
    id: 2, 
    customerName: "Priya Verma",
    items: ["Pizza", "Pepsi"],
    status: "In Progress" 
  },
  { 
    id: 3, 
    customerName: "Amit Singh",
    items: ["Pasta", "Sandwich"],
    status: "Ready for Pickup" 
  },
];

const OrderTracking = () => {
  const [orderStatus, setOrderStatus] = useState(orders);

  const updateStatus = (id) => {
    setOrderStatus(orderStatus.map(order => 
      order.id === id ? { ...order, status: getNextStatus(order.status) } : order
    ));
  };

  const getNextStatus = (currentStatus) => {
    const statuses = ["Pending", "In Progress", "Ready for Pickup", "Completed"];
    const currentIndex = statuses.indexOf(currentStatus);
    return currentIndex < statuses.length - 1 ? statuses[currentIndex + 1] : currentStatus;
  };

  return (
    <div className="order-tracking-container">
      <h2>Order Tracking</h2>
      <div className="orders-list">
        {orderStatus.map(order => (
          <div key={order.id} className="order-card">
            <div className="order-header">
              <h3>Order #{order.id}</h3>
              <span className={`status-badge ${order.status.toLowerCase()}`}>
                {order.status}
              </span>
            </div>
            <div className="order-details">
              <div className="customer-info">
                <strong>Customer Name:</strong>
                <span>{order.customerName}</span>
              </div>
              <div className="items-list">
                <strong>Items:</strong>
                <ul>
                  {order.items.map((item, index) => (
                    <li key={index}>{item}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default OrderTracking;