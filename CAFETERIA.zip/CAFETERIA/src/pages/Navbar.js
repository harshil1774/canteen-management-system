import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link as RouterLink, useNavigate } from 'react-router-dom';
import {
  AppBar,
  Box,
  Toolbar,
  IconButton,
  Typography,
  Menu,
  Container,
  Avatar,
  Button,
  Tooltip,
  MenuItem,
  Badge,
} from '@mui/material';
import {
  Menu as MenuIcon,
  ShoppingCart as CartIcon,
} from '@mui/icons-material';
import { logout } from '../store/slices/authSlice';

const Navbar = () => {
  const [anchorElNav, setAnchorElNav] = useState(null);
  const [anchorElUser, setAnchorElUser] = useState(null);
  const { isAuthenticated, user } = useSelector((state) => state.auth);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleOpenNavMenu = (event) => {
    setAnchorElNav(event.currentTarget);
  };
  const handleOpenUserMenu = (event) => {
    setAnchorElUser(event.currentTarget);
  };

  const handleCloseNavMenu = () => {
    setAnchorElNav(null);
  };

  const handleCloseUserMenu = () => {
    setAnchorElUser(null);
  };

  const handleLogout = () => {
    dispatch(logout());
    handleCloseUserMenu();
    navigate('/login');
  };

  return (
    <AppBar position="static">
      <Container maxWidth="xl">
        <Toolbar disableGutters>
          <Typography
            variant="h6"
            noWrap
            component={RouterLink}
            to="/"
            sx={{
              mr: 2,
              display: { xs: 'none', md: 'flex' },
              fontFamily: 'monospace',
              fontWeight: 700,
              letterSpacing: '.3rem',
              color: 'inherit',
              textDecoration: 'none',
            }}
          >
            CAFETERIA
          </Typography>

          <Box sx={{ flexGrow: 1, display: { xs: 'flex', md: 'none' } }}>
            <IconButton
              size="large"
              aria-controls="menu-appbar"
              aria-haspopup="true"
              onClick={handleOpenNavMenu}
              color="inherit"
            >
              <MenuIcon />
            </IconButton>
            <Menu
              id="menu-appbar"
              anchorEl={anchorElNav}
              anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'left',
              }}
              keepMounted
              transformOrigin={{
                vertical: 'top',
                horizontal: 'left',
              }}
              open={Boolean(anchorElNav)}
              onClose={handleCloseNavMenu}
              sx={{
                display: { xs: 'block', md: 'none' },
              }}
            >
              <MenuItem component={RouterLink} to="/menu" onClick={handleCloseNavMenu}>
                <Typography textAlign="center">Menu</Typography>
              </MenuItem>
              <MenuItem component={RouterLink} to="/contact" onClick={handleCloseNavMenu}>
                <Typography textAlign="center">Contact</Typography>
              </MenuItem>
              <MenuItem component={RouterLink} to="/reviews" onClick={handleCloseNavMenu}>
                <Typography textAlign="center">Reviews</Typography>
              </MenuItem>
              <MenuItem component={RouterLink} to="/cart" onClick={handleCloseNavMenu}>
                <Typography textAlign="center">Cart</Typography>
              </MenuItem>
              <MenuItem component={RouterLink} to="/checkout" onClick={handleCloseNavMenu}>
                <Typography textAlign="center">Checkout</Typography>
              </MenuItem>
              <MenuItem component={RouterLink} to="/payment" onClick={handleCloseNavMenu}>
                <Typography textAlign="center">Payment</Typography>
              </MenuItem>
              <MenuItem component={RouterLink} to="/ordertracking" onClick={handleCloseNavMenu}>
                <Typography textAlign="center">Order Tracking</Typography>
              </MenuItem>
              <MenuItem component={RouterLink} to="/admin" onClick={handleCloseNavMenu}>
                <Typography textAlign="center">Admin Dashboard</Typography>
              </MenuItem>
            </Menu>
          </Box>

          <Typography
            variant="h5"
            noWrap
            component={RouterLink}
            to="/"
            sx={{
              mr: 2,
              display: { xs: 'flex', md: 'none' },
              flexGrow: 1,
              fontFamily: 'monospace',
              fontWeight: 700,
              letterSpacing: '.3rem',
              color: 'inherit',
              textDecoration: 'none',
            }}
          >
            CAFE
          </Typography>

          <Box sx={{ flexGrow: 1, display: { xs: 'none', md: 'flex' } }}>
            <Button
              component={RouterLink}
              to="/menu"
              sx={{ my: 2, color: 'white', display: 'block' }}
            >
              Menu
            </Button>
            <Button
              component={RouterLink}
              to="/contact"
              sx={{ my: 2, color: 'white', display: 'block' }}
            >
              Contact
            </Button>
            <Button
              component={RouterLink}
              to="/reviews"
              sx={{ my: 2, color: 'white', display: 'block' }}
            >
              Reviews
            </Button>
            <Button
              component={RouterLink}
              to="/cart"
              sx={{ my: 2, color: 'white', display: 'block' }}
            >
              Cart
            </Button>
            <Button
              component={RouterLink}
              to="/checkout"
              sx={{ my: 2, color: 'white', display: 'block' }}
            >
              Checkout
            </Button>
            <Button
              component={RouterLink}
              to="/payment"
              sx={{ my: 2, color: 'white', display: 'block' }}
            >
              Payment
            </Button>
            <Button
              component={RouterLink}
              to="/ordertracking"
              sx={{ my: 2, color: 'white', display: 'block' }}
            >
              Order Tracking
            </Button>
            <Button
              component={RouterLink}
              to="/admin"
              sx={{ my: 2, color: 'white', display: 'block' }}
            >
              Admin Dashboard
            </Button>
          </Box>

          <Box sx={{ flexGrow: 0, display: 'flex', alignItems: 'center', gap: 2 }}>
            {isAuthenticated ? (
              <>
                <IconButton
                  component={RouterLink}
                  to="/cart"
                  color="inherit"
                >
                  <Badge badgeContent={0} color="error">
                    <CartIcon />
                  </Badge>
                </IconButton>

                <Tooltip title="Open settings">
                  <IconButton onClick={handleOpenUserMenu} sx={{ p: 0 }}>
                    <Avatar alt={user?.name} src={user?.avatar} />
                  </IconButton>
                </Tooltip>
                <Menu
                  sx={{ mt: '45px' }}
                  id="menu-appbar"
                  anchorEl={anchorElUser}
                  anchorOrigin={{
                    vertical: 'top',
                    horizontal: 'right',
                  }}
                  keepMounted
                  transformOrigin={{
                    vertical: 'top',
                    horizontal: 'right',
                  }}
                  open={Boolean(anchorElUser)}
                  onClose={handleCloseUserMenu}
                >
                  <MenuItem component={RouterLink} to="/profile" onClick={handleCloseUserMenu}>
                    <Typography textAlign="center">Profile</Typography>
                  </MenuItem>
                  {user?.role === 'admin' && (
                    <MenuItem component={RouterLink} to="/admin" onClick={handleCloseUserMenu}>
                      <Typography textAlign="center">Admin Dashboard</Typography>
                    </MenuItem>
                  )}
                  <MenuItem onClick={handleLogout}>
                    <Typography textAlign="center">Logout</Typography>
                  </MenuItem>
                </Menu>
              </>
            ) : (
              <>
                <Button
                  component={RouterLink}
                  to="/login"
                  color="inherit"
                >
                  Login
                </Button>
                <Button
                  component={RouterLink}
                  to="/signup"
                  color="inherit"
                >
                  Sign Up
                </Button>
              </>
            )}
          </Box>
        </Toolbar>
      </Container>
    </AppBar>
  );
};

export default Navbar;
