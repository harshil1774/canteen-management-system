import React from 'react';
import { Link as RouterLink } from 'react-router-dom';
import {
  Box,
  Button,
  Container,
  Grid,
  Typography,
  Card,
  CardMedia,
  CardContent,
  CardActions,
} from '@mui/material';
import { motion } from 'framer-motion';

// Import images
import heroImage from '../images/canteen-hero.jpg';
import burgerImage from '../images/burger.jpg';
import pancakesImage from '../images/pancakes.jpg';
import coffeeImage from '../images/coffee.jpg';

const MotionBox = motion(Box);
const MotionCard = motion(Card);

const HomePage = () => {
  const specialItems = [
    {
      id: 1,
      name: 'Classic Burger',
      description: 'Juicy beef patty with fresh vegetables',
      price: '₹199',
      image: burgerImage,
    },
    {
      id: 2,
      name: 'Fluffy Pancakes',
      description: 'Served with maple syrup and butter',
      price: '₹149',
      image: pancakesImage,
    },
    {
      id: 3,
      name: 'Premium Coffee',
      description: 'Freshly brewed arabica coffee',
      price: '₹99',
      image: coffeeImage,
    },
  ];

  return (
    <Box>
      {/* Hero Section */}
      <Box
        sx={{
          position: 'relative',
          height: '70vh',
          overflow: 'hidden',
        }}
      >
        <Box
          component="img"
          src={heroImage}
          alt="Cafeteria"
          sx={{
            width: '100%',
            height: '100%',
            objectFit: 'cover',
          }}
        />
        <Box
          sx={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <MotionBox
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            sx={{ textAlign: 'center', color: 'white' }}
          >
            <Typography variant="h2" component="h1" gutterBottom>
              Welcome to Our Cafeteria
            </Typography>
            <Typography variant="h5" gutterBottom>
              Delicious meals served fresh every day
            </Typography>
            <Button
              component={RouterLink}
              to="/menu"
              variant="contained"
              size="large"
              sx={{ mt: 4 }}
            >
              View Menu
            </Button>
          </MotionBox>
        </Box>
      </Box>

      {/* Specials Section */}
      <Container sx={{ py: 8 }}>
        <Typography
          variant="h3"
          component="h2"
          align="center"
          gutterBottom
          sx={{ mb: 6 }}
        >
          Today's Specials
        </Typography>
        <Grid container spacing={4}>
          {specialItems.map((item) => (
            <Grid item key={item.id} xs={12} sm={6} md={4}>
              <MotionCard
                whileHover={{ scale: 1.03 }}
                transition={{ duration: 0.2 }}
              >
                <CardMedia
                  component="img"
                  height="200"
                  image={item.image}
                  alt={item.name}
                />
                <CardContent>
                  <Typography gutterBottom variant="h5" component="h3">
                    {item.name}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {item.description}
                  </Typography>
                  <Typography variant="h6" color="primary" sx={{ mt: 2 }}>
                    {item.price}
                  </Typography>
                </CardContent>
                <CardActions>
                  <Button
                    component={RouterLink}
                    to="/menu"
                    size="small"
                    color="primary"
                  >
                    Order Now
                  </Button>
                </CardActions>
              </MotionCard>
            </Grid>
          ))}
        </Grid>
      </Container>

      {/* Features Section */}
      <Box sx={{ bgcolor: 'grey.100', py: 8 }}>
        <Container>
          <Grid container spacing={4}>
            <Grid item xs={12} md={4}>
              <Typography variant="h6" gutterBottom>
                Fresh Ingredients
              </Typography>
              <Typography variant="body1">
                We use only the freshest ingredients to prepare your meals.
              </Typography>
            </Grid>
            <Grid item xs={12} md={4}>
              <Typography variant="h6" gutterBottom>
                Quick Service
              </Typography>
              <Typography variant="body1">
                Fast and efficient service to save your valuable time.
              </Typography>
            </Grid>
            <Grid item xs={12} md={4}>
              <Typography variant="h6" gutterBottom>
                Hygienic Environment
              </Typography>
              <Typography variant="body1">
                We maintain the highest standards of cleanliness and hygiene.
              </Typography>
            </Grid>
          </Grid>
        </Container>
      </Box>
    </Box>
  );
};

export default HomePage;
