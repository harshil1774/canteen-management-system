import React, { useState } from "react";
import { Link } from "react-router-dom";
import {
  Container,
  Grid,
  Card,
  CardMedia,
  CardContent,
  Typography,
  Button,
  Box,
  ButtonGroup,
} from "@mui/material";
import { motion } from "framer-motion";

// Import images
import pancakesImage from '../images/pancakes.jpg';
import burgerImage from '../images/burger.jpg';
import coffeeImage from '../images/coffee.jpg';
import friesImage from '../images/fries.jpg';

const menuItems = [
  {
    id: 1,
    category: "Breakfast",
    name: "Pancakes",
    price: 149,
    description: "Fluffy pancakes served with maple syrup",
    image: pancakesImage,
  },
  {
    id: 2,
    category: "Lunch",
    name: "Burger",
    price: 199,
    description: "Juicy beef patty with fresh vegetables",
    image: burgerImage,
  },
  {
    id: 3,
    category: "Beverages",
    name: "Coffee",
    price: 99,
    description: "Freshly brewed premium coffee",
    image: coffeeImage,
  },
  {
    id: 4,
    category: "Snacks",
    name: "French Fries",
    price: 129,
    description: "Crispy golden fries with special seasoning",
    image: friesImage,
  },
];

const MotionCard = motion(Card);

const MenuPage = () => {
  const [category, setCategory] = useState("All");

  const filteredItems =
    category === "All"
      ? menuItems
      : menuItems.filter((item) => item.category === category);

  return (
    <Container maxWidth="lg" sx={{ py: 8 }}>
      <Typography
        variant="h2"
        component="h1"
        align="center"
        gutterBottom
        sx={{ mb: 6 }}
      >
        Our Menu
      </Typography>

      <Box sx={{ display: "flex", justifyContent: "center", mb: 4 }}>
        <ButtonGroup variant="contained" color="primary">
          {["All", "Breakfast", "Lunch", "Beverages", "Snacks"].map((cat) => (
            <Button
              key={cat}
              onClick={() => setCategory(cat)}
              variant={category === cat ? "contained" : "outlined"}
            >
              {cat}
            </Button>
          ))}
        </ButtonGroup>
      </Box>

      <Grid container spacing={4}>
        {filteredItems.map((item) => (
          <Grid item key={item.id} xs={12} sm={6} md={4}>
            <MotionCard
              whileHover={{ scale: 1.03 }}
              transition={{ duration: 0.2 }}
              sx={{ height: "100%" }}
            >
              <CardMedia
                component="img"
                height="200"
                image={item.image}
                alt={item.name}
                sx={{ objectFit: "cover" }}
              />
              <CardContent>
                <Typography gutterBottom variant="h5" component="h2">
                  {item.name}
                </Typography>
                <Typography
                  variant="body2"
                  color="text.secondary"
                  sx={{ mb: 2 }}
                >
                  {item.description}
                </Typography>
                <Typography variant="h6" color="primary">
                  ₹{item.price}
                </Typography>
                <Button
                  variant="contained"
                  color="primary"
                  fullWidth
                  sx={{ mt: 2 }}
                >
                  Add to Cart
                </Button>
              </CardContent>
            </MotionCard>
          </Grid>
        ))}
      </Grid>

      <Box sx={{ textAlign: "center", mt: 6 }}>
        <Typography variant="h4" component="h2" gutterBottom>
          Ready to Order?
        </Typography>
        <Button
          component={Link}
          to="/cart"
          variant="contained"
          color="primary"
          size="large"
          sx={{ mt: 2 }}
        >
          Go to Cart
        </Button>
      </Box>
    </Container>
  );
};

export default MenuPage;
