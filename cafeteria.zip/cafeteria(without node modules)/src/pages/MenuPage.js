import React, { useState } from "react";
import "./MenuPage.css";

const menuItems = [
  { id: 1, category: "Breakfast", name: "Pancakes", price: 5.99, image: "pancakes.jpg" },
  { id: 2, category: "Lunch", name: "Burger", price: 7.99, image: "burger.jpg" },
  { id: 3, category: "Beverages", name: "Coffee", price: 2.99, image: "coffee.jpg" },
  { id: 4, category: "Snacks", name: "Fries", price: 3.99, image: "fries.jpg" },
];

const MenuPage = () => {
  const [category, setCategory] = useState("All");

  const filteredItems = category === "All" ? menuItems : menuItems.filter(item => item.category === category);

  return (
    <div className="menu-container">
      <h2>Our Menu</h2>
      <div className="category-buttons">
        {['All', 'Breakfast', 'Lunch', 'Beverages', 'Snacks'].map(cat => (
          <button key={cat} onClick={() => setCategory(cat)} className={category === cat ? "active" : ""}>
            {cat}
          </button>
        ))}
      </div>
      <div className="menu-items">
        {filteredItems.map(item => (
          <div key={item.id} className="menu-item">
            <img src={`/images/${item.image}`} alt={item.name} />
            <h3>{item.name}</h3>
            <p>${item.price.toFixed(2)}</p>
            <button className="add-to-cart">Add to Cart</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MenuPage;
