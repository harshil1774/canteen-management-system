import React from "react";
import { Link } from "react-router-dom";
import "./HomePage.css"; // Import CSS for styling

const HomePage = () => {
  return (
    <div className="homepage">
      <section className="hero">
        <h1>Welcome to Our Canteen</h1>
        <p>Delicious meals served fresh every day!</p>
        <img src="/images/canteen-hero.jpg" alt="Cafeteria" />
      </section>
      
      <section className="specials">
        <h2>Today's Specials</h2>
        <ul>
          <li>Grilled Chicken Sandwich - $5.99</li>
          <li>Vegetable Pasta - $4.99</li>
          <li>Fresh Lemonade - $2.49</li>
        </ul>
      </section>
      
      <section className="explore">
        <h2>Explore Our Menu</h2>
        <Link to="/menu" className="explore-button">View Menu</Link>
      </section>
    </div>
  );
};

export default HomePage;
